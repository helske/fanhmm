#ifndef LOGSUMEXP_H
#define LOGSUMEXP_H

#include <RcppArmadillo.h>
double logSumExp(const arma::vec& x);
#endif
