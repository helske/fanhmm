#ifdef _OPENMP
  #include <omp.h>
#endif
