#ifndef CREATEQ_H
#define CREATEQ_H

#include <RcppArmadillo.h>
arma::mat create_Q(const arma::uword n);
#endif
