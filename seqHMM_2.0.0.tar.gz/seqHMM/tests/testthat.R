library(testthat)
library(seqHMM)

test_check("seqHMM")
