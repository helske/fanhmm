#' Imported Functions from `TraMineR`
#'
#' @description Imported functions for convenience. For details, see
#'   the corresponding help pages of [TraMineR::seqstatf()],
#'   [TraMineR::alphabet()] and [TraMineR::seqdef()].
#'
#' @name seqdef
#' @export
#' @rdname TraMineR_imports
NULL
#' @name seqstatf
#' @export
#' @rdname TraMineR_imports
NULL
#' @name alphabet
#' @export
#' @rdname TraMineR_imports
NULL
